import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:typed_data';

class DatabaseHelper {
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    } else {
      _database = await _initDatabase();
      return _database!;
    }
  }

  // Initialize database
  _initDatabase() async {
    String path = join(await getDatabasesPath(), 'image_db.db');
    return await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE images (
          id INTEGER PRIMARY KEY,
          image BLOB
        )
      ''');
    });
  }

  // Insert image into the database
  Future<void> insertImage(Uint8List image) async {
    final db = await database;
    await db.insert('images', {'image': image},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // Retrieve images from the database
  Future<List<Map<String, dynamic>>> getImages() async {
    final db = await database;
    return await db.query('images');
  }
}
