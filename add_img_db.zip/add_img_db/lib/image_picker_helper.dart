import 'dart:typed_data';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

class ImagePickerHelper {
  final ImagePicker _picker = ImagePicker();

  // Pick an image from gallery
  Future<Uint8List?> pickImage() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      File file = File(pickedFile.path);
      Uint8List imageBytes = await file.readAsBytes();
      return imageBytes;
    }
    return null;
  }
}
