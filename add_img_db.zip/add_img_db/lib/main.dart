import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:image_picker/image_picker.dart';
import 'database_helper.dart'; // Import database helper
import 'image_picker_helper.dart'; // Import image picker helper

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ImageInsertPage(),
    );
  }
}

class ImageInsertPage extends StatefulWidget {
  @override
  _ImageInsertPageState createState() => _ImageInsertPageState();
}

class _ImageInsertPageState extends State<ImageInsertPage> {
  final DatabaseHelper _databaseHelper = DatabaseHelper();
  final ImagePickerHelper _imagePickerHelper = ImagePickerHelper();
  Uint8List? _imageBytes;

  // Pick and insert image to SQLite
  Future<void> _pickAndInsertImage() async {
    // Pick an image
    Uint8List? pickedImage = await _imagePickerHelper.pickImage();
    if (pickedImage != null) {
      // Insert the picked image into SQLite
      await _databaseHelper.insertImage(pickedImage);
      setState(() {
        _imageBytes = pickedImage;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Insert Image into SQLite")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _pickAndInsertImage,
              child: Text("Pick and Insert Image"),
            ),
            _imageBytes != null
                ? Image.memory(_imageBytes!) // Display the inserted image
                : Container(),
          ],
        ),
      ),
    );
  }
}
